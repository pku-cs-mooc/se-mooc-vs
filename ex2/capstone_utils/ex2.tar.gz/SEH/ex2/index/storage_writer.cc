#include "index/storage_writer.h"

#include <string>

namespace search {

StorageWriter::~StorageWriter() {
  // TODO: Implement destructor.
}

void StorageWriter::Close() {
  // TODO: Implement this function.
}

void StorageWriter::AddStorage(const std::string& stored) {
  // TODO: Implement this function.
}

}  // namespace search
