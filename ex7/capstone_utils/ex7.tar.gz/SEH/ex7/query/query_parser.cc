#include "query/query_parser.h"

#include <string>
// TODO: Add headers you need.

#include "query/query.h"
// TODO: Add headers you need.

namespace search {

Query* QueryParser::NewQuery(const std::string& str) {
  // TODO: Implement this function.
  return nullptr;
}

}  // namespace search
